Config = {}

Config.positions = {
    {{-1042.58, -2738.51, 19.20, 284.13}, {957.7, 3617.05, 32.17, 86.27}, {255, 247, 0}, "Sandy Shores (Ipswich)"},
    {{-1041.74, -2735.49, 19.20, 242.67}, {2199.91, 5196.29, 59.40, 156.78}, {6, 161, 42}, "Grapeseed (Logan)"},
    {{-1039.54, -2733.09, 19.20, 207.26}, {410.71, 6634.11, 26.73, 139.78}, {6, 107, 161}, "Paleto Bay (Toowoomba)"},
    {{-1032.77, -2736.86, 19.20, 108.79}, {700.28, -302.89, 58.38, 9.91}, {115, 6, 161}, "Mirror Park (North/East Brisbane)"},
    {{-1033.93, -2739.83, 19.20, 62.23}, {302.27, -904.36, 28.13, 70.24}, {52, 177, 235}, "Legion Square (Brisbane)"},
    {{-1036.17, -2742.39, 19.20, 24.49}, {-1108.81, -1496.09, 3.74, 213.58}, {161, 60, 6}, "Vespucci Beach (Gold Coast)"},

    -- Add more teleport locations below as needed
    -- Example:
    -- {{X1, Y1, Z1, Heading1}, {X2, Y2, Z2, Heading2}, {Red, Green, Blue}, "Location Name"},
}

Config.teleportkey = 38 -- The key you press to teleport
Config.notificationkey = 'E' -- The key displayed in the notification
Config.distance = 6.0 -- Distance the markers will unload 