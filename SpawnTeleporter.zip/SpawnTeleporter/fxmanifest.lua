fx_version 'cerulean'
game 'gta5'

description 'Spawn Teleporter for vMenu Servers'
version '1.0'
author 'DS Development'

client_scripts {
    'config.lua', 
    'client.lua', 
}