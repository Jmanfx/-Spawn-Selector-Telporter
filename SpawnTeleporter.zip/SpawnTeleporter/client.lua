key_to_teleport = Config.teleportkey
local positions = Config.positions or {}

local markerVisibility = {}

Citizen.CreateThread(function ()
    while true do
        Citizen.Wait(5)
        local player = GetPlayerPed(-1)
        local playerLoc = GetEntityCoords(player)

        for i, location in ipairs(positions) do
            local teleport_text = location[4]
            local loc1 = {
                x = location[1][1],
                y = location[1][2],
                z = location[1][3],
                heading = location[1][4]
            }

            local loc2 = {
                x = location[2][1],
                y = location[2][2],
                z = location[2][3],
                heading = location[2][4]
            }

            local Red = location[3][1]
            local Green = location[3][2]
            local Blue = location[3][3]

            local markerKey = "marker_" .. i  -- Unique marker key for this location

            if not markerVisibility[markerKey] then
                markerVisibility[markerKey] = false
            end

            local distance = Vdist(playerLoc.x, playerLoc.y, playerLoc.z, loc1.x, loc1.y, loc1.z)

            if distance <= Config.distance then
                if not markerVisibility[markerKey] then
                    markerVisibility[markerKey] = true
                end
            else
                if markerVisibility[markerKey] then
                    markerVisibility[markerKey] = false
                end
            end

            if distance <= 2.0 then
                alert('Press ' .. Config.notificationkey .. ' to teleport to ' .. teleport_text)
            end

            if markerVisibility[markerKey] then
                DrawMarker(25, loc1.x, loc1.y, loc1.z, 0, 0, 0, 0, 0, 0, 1.501, 1.5001, 0.5001, Red, Green, Blue, 200, 0, 0, 0, 0)

                if IsControlJustReleased(1, key_to_teleport) and IsPointInMarker(playerLoc, loc1, 2.0) then
                    SetEntityCoords(player, loc2.x, loc2.y, loc2.z)
                    SetEntityHeading(player, loc2.heading)
                end
            end
        end
    end
end)

function IsPointInMarker(point, marker, size)
    return Vdist(point.x, point.y, point.z, marker.x, marker.y, marker.z) <= size
end

function alert(msg)
    SetTextComponentFormat("STRING")
    AddTextComponentString(msg)
    DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end